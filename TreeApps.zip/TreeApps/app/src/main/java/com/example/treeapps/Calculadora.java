package com.example.treeapps;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Calculadora extends AppCompatActivity {

    private EditText Valor1, Valor2;
    private Button btnSomar, btnDividir, btnMultiplicar, btnSubi, btnVoltar; // Declare o botão voltar aqui
    private TextView Resul;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_calculadora);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Referenciar os componentes da interface
        Valor1 = findViewById(R.id.Valor1);
        Valor2 = findViewById(R.id.Valor2);
        btnSomar = findViewById(R.id.btnSomar);
        btnSubi = findViewById(R.id.btnSub);
        btnDividir = findViewById(R.id.btnDividir);
        btnMultiplicar = findViewById(R.id.btnMulti);
        Resul = findViewById(R.id.Resul);
        btnVoltar = findViewById(R.id.btnVoltar); // Referencie o botão voltar

        // Configurar o clique do botão "Somar"
        btnSomar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                somarValores();
            }
        });

        btnSubi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                subiValores();
            }
        });

        btnMultiplicar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                multiValores();
            }
        });

        btnDividir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dividirValores();
            }
        });

        // Configurar o clique do botão "Voltar"
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Calculadora.this, MainActivity.class);
                startActivity(intent);
            }
        });


    }

    private void somarValores() {
        // Verificar se os campos estão preenchidos
        if (Valor1.getText().toString().isEmpty() || Valor2.getText().toString().isEmpty()) {
            Resul.setText("Por favor, insira ambos os valores.");
            return;
        }

        try {
            // Pegar os valores dos EditText e converter para double
            double valor1 = Double.parseDouble(Valor1.getText().toString());
            double valor2 = Double.parseDouble(Valor2.getText().toString());

            // Realizar a soma
            double resultado = valor1 + valor2;

            // Exibir o resultado no TextView
            Resul.setText("Resultado: " + resultado);
        } catch (NumberFormatException e) {
            // Caso o usuário insira um valor inválido
            Resul.setText("Valores inválidos! Insira apenas números.");
        }
    }

    private void subiValores() {
        // Verificar se os campos estão preenchidos
        if (Valor1.getText().toString().isEmpty() || Valor2.getText().toString().isEmpty()) {
            Resul.setText("Por favor, insira ambos os valores.");
            return;
        }

        try {
            // Pegar os valores dos EditText e converter para double
            double valor1 = Double.parseDouble(Valor1.getText().toString());
            double valor2 = Double.parseDouble(Valor2.getText().toString());

            // Realizar a soma
            double resultado = valor1 - valor2;

            // Exibir o resultado no TextView
            Resul.setText("Resultado: " + resultado);
        } catch (NumberFormatException e) {
            // Caso o usuário insira um valor inválido
            Resul.setText("Valores inválidos! Insira apenas números.");
        }
    }

    private void multiValores() {
        // Verificar se os campos estão preenchidos
        if (Valor1.getText().toString().isEmpty() || Valor2.getText().toString().isEmpty()) {
            Resul.setText("Por favor, insira ambos os valores.");
            return;
        }

        try {
            // Pegar os valores dos EditText e converter para double
            double valor1 = Double.parseDouble(Valor1.getText().toString());
            double valor2 = Double.parseDouble(Valor2.getText().toString());

            // Realizar a soma
            double resultado = valor1 * valor2;

            // Exibir o resultado no TextView
            Resul.setText("Resultado: " + resultado);
        } catch (NumberFormatException e) {
            // Caso o usuário insira um valor inválido
            Resul.setText("Valores inválidos! Insira apenas números.");
        }
    }

    private void dividirValores() {
        // Verificar se os campos estão preenchidos
        if (Valor1.getText().toString().isEmpty() || Valor2.getText().toString().isEmpty()) {
            Resul.setText("Por favor, insira ambos os valores.");
            return;
        }

        try {
            // Pegar os valores dos EditText e converter para double
            double valor1 = Double.parseDouble(Valor1.getText().toString());
            double valor2 = Double.parseDouble(Valor2.getText().toString());

            // Realizar a soma
            double resultado = valor1 / valor2;

            // Exibir o resultado no TextView
            Resul.setText("Resultado: " + resultado);
        } catch (NumberFormatException e) {
            // Caso o usuário insira um valor inválido
            Resul.setText("Valores inválidos! Insira apenas números.");
        }
    }
}